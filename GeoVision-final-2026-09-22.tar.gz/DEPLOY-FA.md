# GeoVision — راهنمای استقرار نسخه نهایی

این بسته شامل قابلیت آدرس رخداد، قفل مأموریت پایان‌یافته، صفحه کارنامه اپراتورها و اصلاح مسیر احراز هویت اپراتورها است.

## اصل مهم دیتابیس

- فایل `prisma/dev.db` داخل بسته نیست و نباید جایگزین شود.
- از `prisma migrate reset`، `prisma migrate dev` و اجرای seed روی سرور استفاده نکنید.
- migration با نام `baseline_operator_sync` روی دیتابیس local فقط به‌عنوان applied ثبت شده است. چون دیتابیس سرور قبلاً با `db push` توسعه یافته، قبل از هر migration باید وضعیت واقعی سرور بررسی شود.

## مرحله اول: فقط بررسی (بدون تغییر)

روی سرور اجرا کنید و خروجی کامل را نگه دارید:

```bash
set -euo pipefail
cd /var/www/geo-mobile-mvp

pm2 list
curl -fsS https://geovision.hosha.ir/api/health
npx prisma migrate status || true

sqlite3 prisma/dev.db "PRAGMA table_info('Incident');"
sqlite3 prisma/dev.db "SELECT name FROM sqlite_master WHERE type='table' AND name IN ('Operator','_prisma_migrations');"
sqlite3 prisma/dev.db "SELECT migration_name, finished_at, rolled_back_at FROM _prisma_migrations ORDER BY started_at;" 2>/dev/null || true

grep -q '^NESHAN_API_KEY=' .env && echo 'NESHAN_API_KEY exists' || echo 'NESHAN_API_KEY is missing'
```

در صورت مشاهده Drift، migration ناموفق، یا نبودن جدول‌های مورد انتظار، ادامه ندهید. ابتدا خروجی بررسی شود تا فقط migration لازم علامت‌گذاری/اجرا شود.

## کنترل‌های انجام‌شده روی بسته

- `npm run typecheck`: موفق
- `npm run build`: موفق
- مسیر جدید: `/admin/operators/[id]`
- فایل دیتابیس، `.env`، `node_modules` و `.next` در بسته وجود ندارند.

## Backfill آدرس

بعد از هماهنگ‌شدن schema و اطمینان از وجود `NESHAN_API_KEY`، اسکریپت زیر فقط رخدادهای دارای `address = NULL` را تکمیل می‌کند و رکوردهای قبلی را حذف نمی‌کند:

```bash
set -a
. ./.env
set +a
npx tsx scripts/backfill-incident-addresses.ts
```

اجرای مرحله cutover، backup و rollback باید بعد از بررسی خروجی مرحله اول انجام شود.
